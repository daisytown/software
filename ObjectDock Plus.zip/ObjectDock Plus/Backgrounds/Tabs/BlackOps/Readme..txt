This skin by MikeB!
http://beta.wincustomize.com/explore/objectdock/16150