Skin by Tiggz!
http://wincustomize.com/skins.aspx?skinid=14009&libid=29