Startmenu Docklet version2.1
-------------------------------
Remove all old startmenu docklet files before installing this.
Create a new folder called "Startmenu2". Place all the files from this zip
in that folder. Right click the dock. choose add and choose "startmenu2 docklet".

Thans to fkewe for requesting the current options :)

Added animation (requested by proenca)
and drag-'n-drop (might be buggy, requested by Leon)

Made by AndreasV - averhoev.2@hccnet.nl









....Francesca.......