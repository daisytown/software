-------------------------------------------------------------------------------

  Capture Docklet v0.2 for Object Dock v0.99+
  by Haitham Al-Beik                              Saturday, August 16th, 2003 
  www.yzdocklets.com
  
-------------------------------------------------------------------------------

Revision History
----------------
 v0.2 (08-26-2003)
   +  First Release


ReadMe First
------------
This docklet lets you take a screen or a window shot and save it to a JPG, 
BMP, PNG or TIFF. You also have the option to include the mouse on the image.

Under settings; the File Format string can be anything you want with any of the 
following dynamic variabes. All variables below must be used as $[variable].

    Format              Provides a format for your file.

      d      Day of month as digits with no leading zero for single-digit days.
      dd     Day of month as digits with leading zero for single-digit days.
      ddd    Day of week as a three-letter abbreviation.
      dddd   Day of week as its full name.
      M      Month as digits with no leading zero for single-digit months.
      MM     Month as digits with leading zero for single-digit months.
      MMM    Month as a three-letter abbreviation.
      MMMM   Month as its full name.
      y      Year as last two digits, but with no leading zero for years less 
             than 10.
      yy     Year as last two digits, but with leading zero for years less 
             than 10.
      yyyy   Year represented by full four digits.
      gg     Period/era string. This element is ignored if the date to be 
             formatted does not have an associated era or period string.

      h      Hours with no leading zero for single-digit hours; 12-hour clock.
      hh     Hours with leading zero for single-digit hours; 12-hour clock.
      H      Hours with no leading zero for single-digit hours; 24-hour clock.
      HH     Hours with leading zero for single-digit hours; 24-hour clock.
      m      Minutes with no leading zero for single-digit minutes.
      mm     Minutes with leading zero for single-digit minutes.
      ss     Seconds with leading zero for single-digit seconds.
      t      One character time-marker string, such as A or P.
      tt     Multicharacter time-marker string, such as AM or PM.

Under settings; the File Path string can be anything you want with any of the 
following dynamic variabes. All variables below must be used as $[variable].

      dp     Is the Capture's Docklet Path
      
Note: An empty path string will capture images at the root folder of OD.


Warning: This program is still beta and it is buggy! Use it for testing purposes
only. 


Installation
------------
  1. Exract the above RAR file inside your Object Dock Docklets folder 

  2. Right click the dock and select "Add ->" then "Capture"


Comments/Suggestions/Problems
-----------------------------
Please email me at albeik@yzdocklets.com! 


Terms of Use
------------
You can reproduce, change and distribute any files in this site, without 
permission as long as this file is included unchanged. 
No liability for the contents of any of the files can be accepted. Use the 
concepts, examples and other content at your own risk. Additionally, this is a 
beta version, possibly with many inaccuracies or errors. And please take into 
consideration that there may be specification change in the future. 

By downloading this docklet you agree to be bound to the terms of use described
at http://www.yzdocklets.com/?pageId=disclaimer.

-------------------------------------------------------------------------------

  http://www.yzdocklets.com/
  Copyright � 2003 Haitham Al-Beik <albeik@yzdocklets.com> 

-------------------------------------------------------------------------------