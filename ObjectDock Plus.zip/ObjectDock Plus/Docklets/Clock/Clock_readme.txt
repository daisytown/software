Default Image by Kyle Haskins (sixfortyfive), thanks kyle looks very nice!


-------------------------------------------------------------------------------

  Clock Docklet v0.1 for Object Dock v0.99a+
  by Haitham Al-Beik                            Saturday, September 5th, 2003 
  www.yzdocklets.com
  
-------------------------------------------------------------------------------

Revision History
----------------
 v0.1 (10-13-2003)
   +  First Release


ReadMe First
------------
This docklet shows you the current time using an Analog format.
This is a port from M.Yamaguchi's version for Y'z Dock.

Warning: This program is still beta and it is buggy! Use it for testing purposes
only. 


Installation
------------
  1. Exract the above RAR file inside your Object Dock 'Docklets' folder 

  2. Right click the dock and select "Add" then "Clock"

Comments/Suggestions/Problems
-----------------------------
Please email me at albeik@yzdocklets.com! 


Terms of Use
------------
You can reproduce, change and distribute any files in this site, without 
permission as long as this file is included unchanged. 
No liability for the contents of any of the files can be accepted. Use the 
concepts, examples and other content at your own risk. Additionally, this is a 
beta version, possibly with many inaccuracies or errors. And please take into 
consideration that there may be specification change in the future. 

By downloading this docklet you agree to be bound to the terms of use described
at http://www.yzdocklets.com/?pageId=disclaimer.

-------------------------------------------------------------------------------

  http://www.yzdocklets.com/
  Copyright � 2003 Haitham Al-Beik <albeik@yzdocklets.com> 

-------------------------------------------------------------------------------

